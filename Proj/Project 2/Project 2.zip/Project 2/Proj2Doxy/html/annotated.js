var annotated =
[
    [ "AbsBS", "class_abs_b_s.html", "class_abs_b_s" ],
    [ "Answer", "struct_answer.html", "struct_answer" ],
    [ "BaseBS", "class_base_b_s.html", "class_base_b_s" ],
    [ "DerivBS", "class_deriv_b_s.html", "class_deriv_b_s" ],
    [ "Guess", "struct_guess.html", "struct_guess" ],
    [ "Guesses", "struct_guesses.html", "struct_guesses" ],
    [ "Stats", "struct_stats.html", "struct_stats" ]
];