var struct_stats =
[
    [ "gamesBS", "struct_stats.html#a679fdc23b194e741932414cbe5454a9c", null ],
    [ "gamesMM", "struct_stats.html#a6e0580e3f7be10af1513ee06c3bf76ae", null ],
    [ "losesBS", "struct_stats.html#a1837a3a29ef77ee9a38e1714baabf541", null ],
    [ "losesMM", "struct_stats.html#a91df5b2494fcd6130cc937e21cb0d91e", null ],
    [ "nGuess", "struct_stats.html#abe30e39a9d36f868b52614055303a441", null ],
    [ "winsBS", "struct_stats.html#aa308622878fa8bd1dbf6cb54113b8cc7", null ],
    [ "winsMM", "struct_stats.html#a67778efa6113d828da9ec3100ccd4ccd", null ]
];