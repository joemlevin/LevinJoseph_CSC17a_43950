var class_deriv_b_s =
[
    [ "DerivBS", "class_deriv_b_s.html#aa13c41866668473c03af6c4572b576dd", null ],
    [ "place", "class_deriv_b_s.html#a91a6a17b3ea1202f98ef1abda62ed76d", null ],
    [ "radar", "class_deriv_b_s.html#a72cb459324280d2f785be88d981a5963", null ],
    [ "target", "class_deriv_b_s.html#a88fb7f686a0ec775d200001d71e8268b", null ]
];