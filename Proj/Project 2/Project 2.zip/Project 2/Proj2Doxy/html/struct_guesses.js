var struct_guesses =
[
    [ "guess", "struct_guesses.html#a5deebe89342ba0296983733405106d0f", null ],
    [ "nGuess", "struct_guesses.html#a3a57ac001df5b0242948bcc6370e8624", null ]
];