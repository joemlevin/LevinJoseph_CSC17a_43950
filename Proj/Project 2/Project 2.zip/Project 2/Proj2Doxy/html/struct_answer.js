var struct_answer =
[
    [ "code", "struct_answer.html#af596c02e70597d78b665f18635bfc02f", null ],
    [ "mxGuess", "struct_answer.html#abf36b626893a5e62cda9917417769681", null ]
];