var dir_2ffe6e6b78c0ceafa2923611e83c4092 =
[
    [ "Cygwin_4.x-Windows", "dir_6ea65c4a76e3ca3878aed808486e16f0.html", "dir_6ea65c4a76e3ca3878aed808486e16f0" ],
    [ "MinGW-Windows", "dir_a588dc0914b939096724b680bd31c644.html", "dir_a588dc0914b939096724b680bd31c644" ]
];