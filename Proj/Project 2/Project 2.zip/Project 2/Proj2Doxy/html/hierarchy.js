var hierarchy =
[
    [ "AbsBS", "class_abs_b_s.html", [
      [ "BaseBS", "class_base_b_s.html", [
        [ "DerivBS", "class_deriv_b_s.html", null ]
      ] ]
    ] ],
    [ "Answer", "struct_answer.html", null ],
    [ "Guess", "struct_guess.html", null ],
    [ "Guesses", "struct_guesses.html", null ],
    [ "Stats", "struct_stats.html", null ]
];