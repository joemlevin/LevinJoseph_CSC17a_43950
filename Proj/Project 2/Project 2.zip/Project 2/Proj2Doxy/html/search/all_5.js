var searchData=
[
  ['gamesbs',['gamesBS',['../struct_stats.html#a679fdc23b194e741932414cbe5454a9c',1,'Stats']]],
  ['gamesmm',['gamesMM',['../struct_stats.html#a6e0580e3f7be10af1513ee06c3bf76ae',1,'Stats']]],
  ['getans',['getAns',['../main_8cpp.html#a99627282ffa9a1a3026bffe776d0c598',1,'main.cpp']]],
  ['getdim',['getDim',['../main_8cpp.html#a91ecd0f151125a462e66139f5be42af5',1,'main.cpp']]],
  ['getg',['getG',['../main_8cpp.html#a7afb1337c2b3b0212cd81755883c1128',1,'main.cpp']]],
  ['getl',['getL',['../main_8cpp.html#a65ffeec2da57b5a355c22f566e169863',1,'main.cpp']]],
  ['getships',['getShips',['../class_abs_b_s.html#a47832f5d1b74da18d8566a33463394b2',1,'AbsBS::getShips()'],['../class_base_b_s.html#a68abece83a96c4b28067242ac903261c',1,'BaseBS::getShips()']]],
  ['guess',['Guess',['../struct_guess.html',1,'Guess'],['../struct_guesses.html#a5deebe89342ba0296983733405106d0f',1,'Guesses::guess()']]],
  ['guesses',['Guesses',['../struct_guesses.html',1,'']]]
];
