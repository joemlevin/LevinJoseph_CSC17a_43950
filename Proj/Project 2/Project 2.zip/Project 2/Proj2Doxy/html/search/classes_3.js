var searchData=
[
  ['guess',['Guess',['../struct_guess.html',1,'']]],
  ['guesses',['Guesses',['../struct_guesses.html',1,'']]]
];
