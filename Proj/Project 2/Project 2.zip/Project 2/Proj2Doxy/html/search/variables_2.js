var searchData=
[
  ['gamesbs',['gamesBS',['../struct_stats.html#a679fdc23b194e741932414cbe5454a9c',1,'Stats']]],
  ['gamesmm',['gamesMM',['../struct_stats.html#a6e0580e3f7be10af1513ee06c3bf76ae',1,'Stats']]],
  ['guess',['guess',['../struct_guesses.html#a5deebe89342ba0296983733405106d0f',1,'Guesses']]]
];
