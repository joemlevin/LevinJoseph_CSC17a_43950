var searchData=
[
  ['winsbs',['winsBS',['../struct_stats.html#aa308622878fa8bd1dbf6cb54113b8cc7',1,'Stats']]],
  ['winsmm',['winsMM',['../struct_stats.html#a67778efa6113d828da9ec3100ccd4ccd',1,'Stats']]]
];
