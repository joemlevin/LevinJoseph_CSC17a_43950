var searchData=
[
  ['stats',['Stats',['../struct_stats.html',1,'']]]
];
