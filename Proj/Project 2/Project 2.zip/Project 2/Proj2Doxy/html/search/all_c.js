var searchData=
[
  ['save',['save',['../main_8cpp.html#a77a153873fdaa648810c7f5fa6891151',1,'main.cpp']]],
  ['seestats',['seeStats',['../main_8cpp.html#a0d04fe70a12f84ed6dfe5bbcd50fb120',1,'main.cpp']]],
  ['ships',['ships',['../class_base_b_s.html#adcf04f00c04d4671c1d76bb957913eec',1,'BaseBS']]],
  ['size',['size',['../class_base_b_s.html#aa4a3daba2f6c708db6d68af8b07956e8',1,'BaseBS']]],
  ['slct',['slct',['../main_8cpp.html#af28f1103e45de44eb4a825b4b080891e',1,'main.cpp']]],
  ['stats',['Stats',['../struct_stats.html',1,'']]],
  ['stats_2eh',['stats.h',['../stats_8h.html',1,'']]]
];
