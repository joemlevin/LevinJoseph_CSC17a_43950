var searchData=
[
  ['losesbs',['losesBS',['../struct_stats.html#a1837a3a29ef77ee9a38e1714baabf541',1,'Stats']]],
  ['losesmm',['losesMM',['../struct_stats.html#a91df5b2494fcd6130cc937e21cb0d91e',1,'Stats']]]
];
