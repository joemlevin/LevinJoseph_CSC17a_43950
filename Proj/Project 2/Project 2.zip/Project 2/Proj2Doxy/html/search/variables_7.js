var searchData=
[
  ['ships',['ships',['../class_base_b_s.html#adcf04f00c04d4671c1d76bb957913eec',1,'BaseBS']]],
  ['size',['size',['../class_base_b_s.html#aa4a3daba2f6c708db6d68af8b07956e8',1,'BaseBS']]]
];
