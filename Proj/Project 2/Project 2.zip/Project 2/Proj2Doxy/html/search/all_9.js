var searchData=
[
  ['nguess',['nGuess',['../struct_guesses.html#a3a57ac001df5b0242948bcc6370e8624',1,'Guesses::nGuess()'],['../struct_stats.html#abe30e39a9d36f868b52614055303a441',1,'Stats::nGuess()']]]
];
