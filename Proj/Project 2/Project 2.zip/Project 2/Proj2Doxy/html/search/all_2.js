var searchData=
[
  ['checkg',['checkG',['../main_8cpp.html#ad53438546df656b6c01a0d7f0edc506b',1,'checkG(Answer *, Guess *, int):&#160;main.cpp'],['../main_8cpp.html#a21d52268f58ebd14a24ab9c24a7aa62d',1,'checkG(Answer *a, Guesses *g, int row):&#160;main.cpp']]],
  ['clrscrn',['clrscrn',['../main_8cpp.html#aaf54be9b5e58dcba705e977846caaccb',1,'main.cpp']]],
  ['code',['code',['../struct_answer.html#af596c02e70597d78b665f18635bfc02f',1,'Answer::code()'],['../struct_guess.html#a8e379999165b201011ccc70862351f65',1,'Guess::code()']]],
  ['cornum',['corNum',['../struct_guess.html#a9ee11556cfeeff34b7be2b1c1a17ace3',1,'Guess']]],
  ['corpos',['corPos',['../struct_guess.html#aa576fa549207d4a1e311c6be2717bafd',1,'Guess']]]
];
