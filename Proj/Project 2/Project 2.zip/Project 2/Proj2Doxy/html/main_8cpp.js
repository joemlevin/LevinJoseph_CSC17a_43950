var main_8cpp =
[
    [ "again", "main_8cpp.html#a312963dc450a4da7adb8f53385600800", null ],
    [ "checkG", "main_8cpp.html#ad53438546df656b6c01a0d7f0edc506b", null ],
    [ "checkG", "main_8cpp.html#a21d52268f58ebd14a24ab9c24a7aa62d", null ],
    [ "clrscrn", "main_8cpp.html#aaf54be9b5e58dcba705e977846caaccb", null ],
    [ "getAns", "main_8cpp.html#a99627282ffa9a1a3026bffe776d0c598", null ],
    [ "getDim", "main_8cpp.html#a91ecd0f151125a462e66139f5be42af5", null ],
    [ "getG", "main_8cpp.html#a7afb1337c2b3b0212cd81755883c1128", null ],
    [ "getL", "main_8cpp.html#a65ffeec2da57b5a355c22f566e169863", null ],
    [ "instrct", "main_8cpp.html#a1805138975ee4f74ec931280eaa7f52e", null ],
    [ "load", "main_8cpp.html#a376d77019fd51be769b03b50f313ae2e", null ],
    [ "main", "main_8cpp.html#a3c04138a5bfe5d72780bb7e82a18e627", null ],
    [ "menu", "main_8cpp.html#a40367ec6ab7c61ae3bdef5ec38d0becc", null ],
    [ "pAns", "main_8cpp.html#abed6b3fd15a6b75bba126ce2ea11c88d", null ],
    [ "pBoard", "main_8cpp.html#abd1ef90d7b557471aa6605db29a27b5a", null ],
    [ "play", "main_8cpp.html#ac2871a080eb5a5a5f743c638c925c16b", null ],
    [ "playBS", "main_8cpp.html#a32a4cde9e0c70be230c4642f9f7e1913", null ],
    [ "playMM", "main_8cpp.html#a3ed707663c1c4cf2985c3fbc5ab1605b", null ],
    [ "purge", "main_8cpp.html#ab19329ca04728ddaf68412b4b736523f", null ],
    [ "save", "main_8cpp.html#a77a153873fdaa648810c7f5fa6891151", null ],
    [ "seeStats", "main_8cpp.html#a0d04fe70a12f84ed6dfe5bbcd50fb120", null ],
    [ "slct", "main_8cpp.html#af28f1103e45de44eb4a825b4b080891e", null ]
];