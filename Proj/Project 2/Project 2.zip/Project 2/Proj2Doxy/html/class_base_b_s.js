var class_base_b_s =
[
    [ "BaseBS", "class_base_b_s.html#a299b6d4e7798fa976797f16d67977505", null ],
    [ "~BaseBS", "class_base_b_s.html#ae855ad8486bbbe3e9ec4f59252083728", null ],
    [ "flBoard", "class_base_b_s.html#aebd06c9f062acfa63767894671bdcec9", null ],
    [ "getShips", "class_base_b_s.html#a68abece83a96c4b28067242ac903261c", null ],
    [ "pBoard", "class_base_b_s.html#a40109240b9c756b843713059167930b6", null ],
    [ "place", "class_base_b_s.html#ab2aa65fcb5e7fca6597884edf8c16e36", null ],
    [ "target", "class_base_b_s.html#aecbb74e43e2ab27752d3433c290e1934", null ],
    [ "board", "class_base_b_s.html#ab9b96f81123f36ccf9dd093575c8c92c", null ],
    [ "piece", "class_base_b_s.html#ac43dfa9f06ca96b7a90d8d493db75f6c", null ],
    [ "ships", "class_base_b_s.html#adcf04f00c04d4671c1d76bb957913eec", null ],
    [ "size", "class_base_b_s.html#aa4a3daba2f6c708db6d68af8b07956e8", null ]
];