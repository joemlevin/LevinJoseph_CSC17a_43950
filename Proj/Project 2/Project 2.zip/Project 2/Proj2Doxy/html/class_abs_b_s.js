var class_abs_b_s =
[
    [ "flBoard", "class_abs_b_s.html#ad6911e1985f3b92d704b98bcac119674", null ],
    [ "getShips", "class_abs_b_s.html#a47832f5d1b74da18d8566a33463394b2", null ],
    [ "pBoard", "class_abs_b_s.html#a62479a30bef5b16100f31dedafb3d6bd", null ]
];