/* 
 * File:   Report.h
 * Author: Joseph
 *
 * Created on April 17, 2015, 3:22 PM
 */

#ifndef REPORT_H
#define	REPORT_H

struct Report{
    std::string name;
    int quarter[4]={1,2,3,4}, sales[16];
};


#endif	/* REPORT_H */

